import unittest

class FooTest(unittest.TestCase):
    
    def test_foo(self):
        self.assertTrue(True)
