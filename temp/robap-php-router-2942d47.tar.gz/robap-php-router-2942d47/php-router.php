<?php
include_once(dirname(__FILE__) . '/lib/Route.php');
include_once(dirname(__FILE__) . '/lib/Router.php');
include_once(dirname(__FILE__) . '/lib/Dispatcher.php');

?>
